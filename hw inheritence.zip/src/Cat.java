
public class Cat extends Animals {

	private String name;
	private double lives;
	
	public Cat(double weight, double height, String name, double lives) {
		super(weight, height);
		this.name = name;
		this.lives = lives;
		
		
	}

	@Override
	public String toString() {
	String result = "\nI am a cat. \n";
	result += "My name is " + name + '.';
	result += "\nI have " + lives + " lives.";
	result += super.toString();
	
	return result;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getLives() {
		return lives;
	}

	public void setLives(double lives) {
		this.lives = lives;
	}




	}

	
	

