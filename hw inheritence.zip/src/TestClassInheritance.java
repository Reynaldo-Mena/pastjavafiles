
public class TestClassInheritance {

	public static void main(String[] args) {
		Animals []animals = new Animals[50];
		int eSize = 0;
		
		Animals myAnimal = new Animals(30,5);
		animals[eSize] = myAnimal;
		eSize ++;
		
		Dog myDog = new Dog(100, 3, "rover", "mutt","5/5/5");
		animals[eSize] = myDog;
		eSize++;
		
		Cat myCat = new Cat(20, 9,"billy",5);
		animals[eSize] = myCat;
		eSize++;
		
		Bird newBird = new Bird(2, 5, true, 15);
		animals[eSize] = newBird;
		eSize++;
		
		
		displayAnimal(animals, eSize); 
	}//end main

//----------------------------------------------------------------------------

	private static void displayAnimal(Animals[] animals, int eSize) {
		for (int i = 0; i< eSize; i++) {
		System.out.println(animals[i]);
		}

	}// end display
	
	
	
}// end class
