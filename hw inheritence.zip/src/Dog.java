
public class Dog extends Animals{
	private String name;
	private String breed;
	
	private String date;


	public Dog(double weight, double height, String name, String breed, String date) {
		super(weight, height);
		this.name = name;
		this.breed = breed;
		this.date = date;
	}

	public String getName() {
	return name;
	}

	public void setName(String name) {
	this.name = name;
	}

	public String getBreed() {
	return breed;
	}

	public void setBreed(String breed) {
	this.breed = breed;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	@Override
	public String toString() {
	String result = "\nI am a dog. \n";
	result += "My breed is " + breed + '.';
	result += "\nMy name is " + name + '.';
	result += "\nMy DOB is " + date;
	result += super.toString();
	return result;
	}


	}


	
	
	
	


