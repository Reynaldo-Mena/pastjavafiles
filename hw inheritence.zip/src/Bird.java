
public class Bird extends Animals{
	
	private boolean fly;
	private double wingspan;
	
	
	public Bird(double weight, double height, boolean fly, double wingspan) {
		super(weight, height);
		this.fly = fly;
		this.wingspan = wingspan;
	}
	
	
	
	public boolean isFly() {
		return fly;
	}
	public void setFly(boolean fly) {
		this.fly = fly;
	}
	public double getWingspan() {
		return wingspan;
	}
	public void setWingspan(double wingspan) {
		this.wingspan = wingspan;
	}
	
	
	@Override
	public String toString() {
		String result = "I am a Bird. \n" ;
		if(fly){
			result += "I can fly. \n";
		}else result += "I cannot fly. \n";
		result += "My wingspan is " + wingspan + " inches wide.";
		result += super.toString();
		return result;
	}
}
